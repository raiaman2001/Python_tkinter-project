from tkinter import *
from customtkinter import *
root=Tk()
root.geometry("280x390")
root.title("Calculator")
root.resizable(False,False)

operator=''
def cal(number):
    global operator
    operator=operator+number
    res.delete(0,END)
    res.insert(END,operator)

def Clear():
    global operator
    operator=''
    res.delete(0,END)
    
def ans():
    global operator
    result=str(eval(operator)) 
    res.delete(0,END)   
    res.insert(0,result)
    operator=''
    
res=Entry(root,font=("Bold",20),bd=5,justify=RIGHT)
res.place(x=0,y=0,width=270,height=50)

clear_btn=CTkButton(master=root,text="C",width=40,height=40,font=("Bold",15),fg_color="red",corner_radius=12,command=Clear)
clear_btn.place(x=15,y=75)

bracket_btn=CTkButton(master=root,text="()",width=40,height=40,font=("Bold",15),fg_color="red",corner_radius=12,
                      command=lambda:cal('()'))
bracket_btn.place(x=80,y=75)

per_btn=CTkButton(master=root,text="%",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                  command=lambda:cal('%'))
per_btn.place(x=145,y=75)

div_btn=CTkButton(master=root,text="➗",width=25,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                  command=lambda:cal('/'))
div_btn.place(x=210,y=75)

seven_btn=CTkButton(master=root,text="7",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                    command=lambda:cal('7'))
seven_btn.place(x=15,y=140)

eight_btn=CTkButton(master=root,text="8",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                    command=lambda:cal('8'))
eight_btn.place(x=80,y=140)

nine_btn=CTkButton(master=root,text="9",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                   command=lambda:cal('9'))
nine_btn.place(x=145,y=140)

mul_btn=CTkButton(master=root,text="✖️",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                  command=lambda:cal('*'))
mul_btn.place(x=210,y=140)

four_btn=CTkButton(master=root,text="4",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                   command=lambda:cal('4'))
four_btn.place(x=15,y=205)

five_btn=CTkButton(master=root,text="5",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                   command=lambda:cal('5'))
five_btn.place(x=80,y=205)

six_btn=CTkButton(master=root,text="6",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                  command=lambda:cal('6'))
six_btn.place(x=145,y=205)

sub_btn=CTkButton(master=root,text="➖",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                  command=lambda:cal('-'))
sub_btn.place(x=210,y=205)

one_btn=CTkButton(master=root,text="1",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                  command=lambda:cal('1'))
one_btn.place(x=15,y=270)

two_btn=CTkButton(master=root,text="2",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                  command=lambda:cal('2'))
two_btn.place(x=80,y=270)

three_btn=CTkButton(master=root,text="3",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                    command=lambda:cal('3'))
three_btn.place(x=145,y=270)

add_btn=CTkButton(master=root,text="➕",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                  command=lambda:cal('+'))
add_btn.place(x=210,y=270)

equal_btn=CTkButton(master=root,text="🟰",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                    command=ans)
equal_btn.place(x=80,y=335)

point_btn=CTkButton(master=root,text=".",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                    command=lambda:cal('.'))
point_btn.place(x=145,y=335)

zero_btn=CTkButton(master=root,text="0",width=40,height=40,font=("Bold",15),fg_color="green",corner_radius=12,
                   command=lambda:cal('0'))
zero_btn.place(x=210,y=335)

root.mainloop()